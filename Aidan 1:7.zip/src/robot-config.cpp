#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
controller Controller1 = controller(primary);
motor rf = motor(PORT1, ratio6_1, false);
motor rm = motor(PORT2, ratio6_1, false);
motor rb = motor(PORT3, ratio6_1, false);
motor lf = motor(PORT4, ratio6_1, true);
motor lm = motor(PORT5, ratio6_1, true);
motor lb = motor(PORT6, ratio6_1, true);
motor cata = motor(PORT11, ratio18_1, true);
motor intake = motor(PORT12, ratio6_1, true);
inertial Inertial = inertial(PORT7);
rotation Rotation = rotation(PORT8, false);
digital_out wings = digital_out(Brain.ThreeWirePort.H);
digital_out hang = digital_out(Brain.ThreeWirePort.G);

// VEXcode generated functions
// define variable for remote controller enable/disable
bool RemoteControlCodeEnabled = true;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  // nothing to initialize
}