using namespace vex;

extern brain Brain;

// VEXcode devices
extern controller Controller1;
extern motor rf;
extern motor rm;
extern motor rb;
extern motor lf;
extern motor lm;
extern motor lb;
extern motor cata;
extern motor intake;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );