/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       eric                                                      */
/*    Created:      Sat Dec 23 2023                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// rf                   motor         1               
// rm                   motor         2               
// rb                   motor         3               
// lf                   motor         4               
// lm                   motor         5               
// lb                   motor         6               
// cata                 motor         11              
// intake               motor         12              
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

competition Competition;

float pi = 3.1415;
float diameter = 2.75;
bool toggle2 = false; 
bool latch2 = false;

void singledt(double x,double y) {
  double rightspeed = (Controller1.Axis3.position() * y) + (Controller1.Axis4.position() * -x);
  double leftspeed = (Controller1.Axis3.position() * y) - (Controller1.Axis4.position() * -x);
  lf.setVelocity(leftspeed,percent);
  lm.setVelocity(leftspeed,percent);
  lb.setVelocity(leftspeed,percent);
  rf.setVelocity(rightspeed,percent);
  rm.setVelocity(rightspeed,percent);
  rb.setVelocity(rightspeed,percent);
  lf.spin(forward);
  lm.spin(forward);
  lb.spin(forward);
  rf.spin(forward);
  rm.spin(forward);
  rb.spin(forward);
}

void splitdt(double x,double y) {
  double rightspeed = (Controller1.Axis3.position() * y) + (Controller1.Axis1.position() * -x);
  double leftspeed = (Controller1.Axis3.position() * y) - (Controller1.Axis1.position() * -x);
  lf.setVelocity(leftspeed,percent);
  lm.setVelocity(leftspeed,percent);
  lb.setVelocity(leftspeed,percent);
  rf.setVelocity(rightspeed,percent);
  rm.setVelocity(rightspeed,percent);
  rb.setVelocity(rightspeed,percent);
  lf.spin(forward);
  lm.spin(forward);
  lb.spin(forward);
  rf.spin(forward);
  rm.spin(forward);
  rb.spin(forward);
}

void turn_to_angle(float targetAngle) {
   
    Inertial.setHeading(0, degrees);
    float kp = 0.7; 
    float ki = 0.03;
    float kd = 0.4;
    float starti = 15;
    float settle_error = 1.0; 
    float settle_time = 20.0; 
    float timeout = 5000.0; 


    float accumulated_error = 0;
    float previous_error = 0;
    float output = 0;
    float time_spent_settled = 0;
    float time_spent_running = 0;


    float currentAngle = 0;

    while (true) {

        currentAngle = Inertial.heading(degrees);


        float error = targetAngle - currentAngle;
        

        if (error > 180) {
          error -= 360;
        }
        if (error < -180) {
          error += 360;
        }


        if (fabs(error) < starti) {
            accumulated_error += error;
        }
        if ((error > 0 && previous_error < 0) || (error < 0 && previous_error > 0)) {
            accumulated_error = 0;
        }

        output = kp * error + ki * accumulated_error + kd * (error - previous_error);
        previous_error = error;

        if (fabs(error) < settle_error) {
            time_spent_settled += 20;
        } else {
            time_spent_settled = 0;
        }

        time_spent_running += 20;


        lf.spin(forward, output, percent);
        lm.spin(forward, output, percent);
        lb.spin(forward, output, percent);
        rf.spin(reverse, output, percent);
        rm.spin(reverse, output, percent);
        rb.spin(reverse, output, percent);


        if (time_spent_running > timeout || time_spent_settled > settle_time) {
            break; 
        }

        wait(20, msec); 
        /*
        Controller1.Screen.clearScreen();
        Controller1.Screen.setCursor(1,1);
        Controller1.Screen.print("Inertial Heading : %f, ", Inertial7.heading(degrees));
        Controller1.Screen.setCursor(2,1);
        Controller1.Screen.print("Time Spent Settled : %f, ", time_spent_settled);
        Controller1.Screen.setCursor(3,1);
        Controller1.Screen.print("Time Spent : %f, ", time_spent_running);
        */
    }

    lf.stop();
    lm.stop();
    lb.stop();
    rf.stop();
    rm.stop();
    rb.stop();
}

void Forward(float targetin, int speed) {

  float traveledin = 0;

  while (traveledin <= targetin) {
    rf.spin(forward, speed, percent);
    rm.spin(forward, speed, percent);
    rb.spin(forward, speed, percent);
    lf.spin(forward, speed, percent);
    lm.spin(forward, speed, percent);
    lb.spin(forward, speed, percent);
    wait(10, msec);
    traveledin = rf.rotation(rev)*pi*diameter;
  }

    rf.stop();
    rm.stop();
    rb.stop();
    lf.stop();
    lm.stop();
    lb.stop();
}

void Backward(float targetin, int speed) {

  float traveledin = 0;

  while (traveledin <= targetin) {
    rf.spin(reverse, speed, percent);
    rm.spin(reverse, speed, percent);
    rb.spin(reverse, speed, percent);
    lf.spin(reverse, speed, percent);
    lm.spin(reverse, speed, percent);
    lb.spin(reverse, speed, percent);
    wait(10, msec);
    traveledin = rf.rotation(rev)*pi*diameter;
  }

    rf.stop();
    rm.stop();
    rb.stop();
    lf.stop();
    lm.stop();
    lb.stop();
}

int auton = 1;
int noa = 4;
void autonselector() {
 if (auton>noa){
   auton=1;
 }
if (auton<1){
   auton=noa;
}
if(Controller1.Axis1.position(percent) > 5){
   auton++;
   wait(0.5,seconds);
}
if(Controller1.Axis1.position(percent) < -5){
   auton--;
   wait(0.5,seconds);
}
if(auton == 1){
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1,1);
  Controller1.Screen.print("Far");
}
if(auton == 2){
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1,1);
  Controller1.Screen.print("Near");
  }
if(auton == 3){
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1,1);
  Controller1.Screen.print("NearElims");
  }  
if(auton == 4){
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1,1);
  Controller1.Screen.print("Skills");
  }  
}

void pre_auton(void) {
  vexcodeInit();

}

void autonomous(void) {

  lf.setStopping(hold);
  lm.setStopping(hold);
  lb.setStopping(hold);
  rf.setStopping(hold);
  rm.setStopping(hold);
  rb.setStopping(hold);
  
  if (auton == 1){
  auton1();
  }

  if (auton == 2){
  auton2();
  }

  if (auton == 3){
  auton3();
  }

   if (auton == 4){
  auton4();
  }
}


void usercontrol(void) {

  while (true){
    splitdt(0.5, 1);
    lf.setStopping(coast);
    lm.setStopping(coast);
    lb.setStopping(brake);
    rf.setStopping(coast);
    rm.setStopping(coast);
    rb.setStopping(brake);

// intake

    if (Controller1.ButtonR1.pressing()){
      intake.spin(reverse,90,percent);
    }
    if (Controller1.ButtonR2.pressing()){
      intake.spin(forward,90,percent);
    }
    if(!Controller1.ButtonR2.pressing()&& !Controller1.ButtonR1.pressing()){
    intake.stop();
      }
  
//cata

    if (toggle2){
      cata.spin(reverse,100,percent); 
    } 
    else {
      cata.stop();
    }
    if (Controller1.ButtonA.pressing()) {
      if(!latch2){ 
        toggle2 = !toggle2;
        latch2 = true;
      }
    } 
    else {
      latch2 = false; 
    }
  }
}

int main() {
  Competition.drivercontrol(usercontrol);
while (true) {
  
  wait(20,msec);
}
}
  



