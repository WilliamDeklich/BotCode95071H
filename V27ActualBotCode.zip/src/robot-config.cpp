#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
controller Controller1 = controller(primary);
motor intake = motor(PORT20, ratio6_1, false);
motor cata = motor(PORT11, ratio18_1, false);
motor rb = motor(PORT5, ratio6_1, false);
motor rt = motor(PORT3, ratio6_1, true);
motor rf = motor(PORT1, ratio6_1, false);
motor lf = motor(PORT2, ratio6_1, true);
motor lb = motor(PORT6, ratio6_1, true);
motor lt = motor(PORT4, ratio6_1, false);
digital_out LeftWing = digital_out(Brain.ThreeWirePort.A);
digital_out IntakePiston = digital_out(Brain.ThreeWirePort.G);
digital_out RightWing = digital_out(Brain.ThreeWirePort.F);
digital_out HangMech = digital_out(Brain.ThreeWirePort.H);
inertial Inertial21 = inertial(PORT21);

// VEXcode generated functions
// define variable for remote controller enable/disable
bool RemoteControlCodeEnabled = true;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  // nothing to initialize
}