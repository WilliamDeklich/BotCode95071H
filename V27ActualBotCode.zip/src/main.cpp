/*----------------------------------------------------------------------------*/
/* */
/* Module: main.cpp */
/* Author: VEX */
/* Created: Thu Sep 26 2019 */
/* Description: Competition Template */
/* */
/*----------------------------------------------------------------------------*/




// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// intake               motor         20              
// cata                 motor         11              
// rb                   motor         5               
// rt                   motor         3               
// rf                   motor         1               
// lf                   motor         2               
// lb                   motor         6               
// lt                   motor         4               
// LeftWing             digital_out   A               
// IntakePiston         digital_out   G               
// RightWing            digital_out   F               
// HangMech             digital_out   H               
// Inertial21           inertial      21              
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

competition Competition;


bool toggle = false; 
bool latch = false;
bool toggle2 = false; 
bool latch2 = false;
bool toggle3 = false; 
bool latch3 = false;
bool toggle4 = false; 
bool latch4 = false;
bool selected = true;

void Forward(double duration, int speed) {
    
    rf.spin(forward, speed, percent);
    rt.spin(forward, speed, percent);
    rb.spin(forward, speed, percent);
    lf.spin(forward, speed, percent);
    lt.spin(forward, speed, percent);
    lb.spin(forward, speed, percent);

    double stopTime = Brain.timer(vex::timeUnits::sec) + duration;

    while (Brain.timer(vex::timeUnits::sec) < stopTime) {
    }

    rf.stop();
    rt.stop();
    rb.stop();
    lf.stop();
    lt.stop();
    lb.stop();
}


void Backward(double duration, int speed) {
    
    rf.spin(reverse, speed, percent);
    rt.spin(reverse, speed, percent);
    rb.spin(reverse, speed, percent);
    lf.spin(reverse, speed, percent);
    lt.spin(reverse, speed, percent);
    lb.spin(reverse, speed, percent);

    double stopTime = Brain.timer(vex::timeUnits::sec) + duration;

    while (Brain.timer(vex::timeUnits::sec) < stopTime) {
    }

    
    rf.stop();
    rt.stop();
    rb.stop();
    lf.stop();
    lt.stop();
    lb.stop();
}

void TurnRight(double duration) {
    int speed = 20;  
    
    lf.spin(forward, speed, percent);
    lt.spin(forward, speed, percent);
    lb.spin(forward, speed, percent);

    double stopTime = Brain.timer(vex::timeUnits::sec) + duration;

    while (Brain.timer(vex::timeUnits::sec) < stopTime) {

    }

    lf.stop();
    lt.stop();
    lb.stop();
}
void FullRight(double duration) {
    int speed = 20;  
    
    lf.spin(forward, speed, percent);
    lt.spin(forward, speed, percent);
    lb.spin(forward, speed, percent);
    rf.spin(reverse, speed, percent);
    rt.spin(reverse, speed, percent);
    rb.spin(reverse, speed, percent);

    double stopTime = Brain.timer(vex::timeUnits::sec) + duration;

    while (Brain.timer(vex::timeUnits::sec) < stopTime) {

    }

    lf.stop();
    lt.stop();
    lb.stop();
}
void TurnLeft(double duration) {
    int speed = 20;  
    
   
    rf.spin(forward, speed, percent);
    rt.spin(forward, speed, percent);
    rb.spin(forward, speed, percent);
    
    double stopTime = Brain.timer(vex::timeUnits::sec) + duration;

    while (Brain.timer(vex::timeUnits::sec) < stopTime) {
    }
    rf.stop();
    rt.stop();
    rb.stop();
    
}
void FullLeft(double duration) {
    int speed = 20;  
    
   
    rf.spin(forward, speed, percent);
    rt.spin(forward, speed, percent);
    rb.spin(forward, speed, percent);
    lf.spin(reverse, speed, percent);
    lt.spin(reverse, speed, percent);
    lb.spin(reverse, speed, percent);
    
    double stopTime = Brain.timer(vex::timeUnits::sec) + duration;

    while (Brain.timer(vex::timeUnits::sec) < stopTime) {
    }
    rf.stop();
    rt.stop();
    rb.stop();
    
}
int auton = 1;
int noa = 3;
void autonselector() {
 if (auton>noa){
   auton=1;
 }
if (auton<1){
   auton=noa;
}
if(Controller1.Axis1.position(percent) > 5){
   auton++;
   wait(0.5,seconds);
}
if(Controller1.Axis1.position(percent) < -5){
   auton--;
   wait(0.5,seconds);
}
if(auton == 1){
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1,1);
  Controller1.Screen.print("Far");
}
if(auton == 2){
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1,1);
  Controller1.Screen.print("Near");
  }
if(auton == 3){
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1,1);
  Controller1.Screen.print("Skills");
  }  
}

void dtCode(double x,double y) {
  double rightspeed = (Controller1.Axis3.position() * y) + (Controller1.Axis4.position() * -x);
  double leftspeed = (Controller1.Axis3.position() * y) - (Controller1.Axis4.position() * -x);
  lf.setVelocity(leftspeed,percent);
  lb.setVelocity(leftspeed,percent);
  lt.setVelocity(leftspeed,percent);
  rf.setVelocity(rightspeed,percent);
  rb.setVelocity(rightspeed,percent);
  rt.setVelocity(rightspeed,percent);
  lf.spin(forward);
  lb.spin(forward);
  lt.spin(forward);
  rf.spin(forward);
  rb.spin(forward);
  rt.spin(forward);
}

void auton1(){
   Forward(1.5,40);
  intake.spin(forward,100,percent);
  wait(1, sec);
  intake.stop();
  Backward(0.5,40);
  TurnLeft(0.25);
  Forward(0.7,90);
  Backward(1,6);
  Forward(0.5,40);
  intake.spin(reverse,90,percent);
  Forward(1.9,40);
  TurnRight(2.5);
  Forward(0.6,40);
  intake.spin(forward,90,percent);
  Forward(0.6,40);
  Backward(0.5,40);
  TurnRight(0.35);
  Forward(0.9, 90);
  intake.stop();
  Backward(0.5,40);
}

void auton2(){
  Forward(1.5,40);
  intake.spin(forward,100,percent);
  wait(1, sec);
  intake.stop();
  Backward(0.5,40);
  TurnRight(0.25);
  Forward(0.7,90);
  Backward(1,66);
  Forward(0.5,40);
  intake.spin(reverse,90,percent);
  Forward(2.25,40);
  TurnLeft(3);
  Forward(1,40);
  intake.spin(forward,90,percent);
  Backward(0.5,40);
  TurnRight(0.3);
  Forward(0.9, 90);
  intake.stop();
}
void auton3(){
  IntakePiston.set(true);
  cata.spin(reverse, 90, percent);
  intake.spin(reverse, 90, percent);
  wait(55,seconds);
  Backward(5,90);
}





void pre_auton(void) {
  vexcodeInit();
  IntakePiston.set(true);
}

void autonomous(void) {
  IntakePiston.set(false);
  lf.setStopping(hold);
  lb.setStopping(hold);
  lt.setStopping(hold);
  rf.setStopping(hold);
  rb.setStopping(hold);
  rt.setStopping(hold);
  if (auton == 1){
  auton1();
  }
  if (auton == 2){
  auton2();
  }
  if (auton == 3){
    auton3();
  }

}

void usercontrol(void) {

  while (true){
    dtCode(0.4, 1);
    autonselector();
    lf.setStopping(brake);
    lb.setStopping(brake);
    lt.setStopping(coast);
    rf.setStopping(brake);
    rb.setStopping(brake);
    rt.setStopping(coast);

    //Intake
    if (Controller1.ButtonR1.pressing()){
      intake.spin(reverse,90,percent);
    }
    if (Controller1.ButtonR2.pressing()){
      intake.spin(forward,90,percent);
    }
    if(!Controller1.ButtonR2.pressing()&& !Controller1.ButtonR1.pressing()){
    intake.stop();
      }
    //HangMech
    if(Controller1.ButtonLeft.pressing() && (Controller1.ButtonL2.pressing())){
    HangMech.set(true);
      }
    //FlyWheel
    if (toggle2){
      cata.spin(reverse,100,percent); 
    } 
    else {
      cata.stop();
    }
    if (Controller1.ButtonA.pressing()) {
      if(!latch2){ 
        toggle2 = !toggle2;
        latch2 = true;
      }
    } 
    else {
      latch2 = false; 
    }
    //Left Wing
    if (toggle){
      LeftWing.set(true);  
    } 
    else {
      LeftWing.set(false);
    }

    if (Controller1.ButtonL1.pressing()) {
      if(!latch){ 
        toggle = !toggle;
        latch = true;
      }
    } 
    else {
      latch = false; 
    }
    //Right Wing
    if (toggle3){
      RightWing.set(true); 
    } 
    else {
      
      RightWing.set(false); 
    }

    if (Controller1.ButtonR1.pressing()) {
      if(!latch3){ 
        toggle3 = !toggle3;
        latch3 = true;
      }
    } 
    else {
      latch3 = false; 
    }
    //IntakePiston
        if (toggle4){
      IntakePiston.set(false); 
    } 
    else {
      IntakePiston.set(true); 
    }
    if (Controller1.ButtonR2.pressing()) {
      if(!latch4){ 
        toggle4 = !toggle4;
        latch4 = true;
      }
    } 
    else {
      latch4 = false; 
    }
    }
}

int main() {
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);
  pre_auton();
while (true) {
  
  wait(20,msec);
  }
}

