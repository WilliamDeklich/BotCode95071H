#pragma once
#include "vex.h"

class Drive
{
private:
  float wheel_diameter;
  float wheel_ratio;
  float drive_in_to_deg_ratio;

public: 
  Drive(float wheel_diameter, float wheel_ratio);

  float left_position();
  float right_position();

  void turn_to_angle(float targetAngle);

  void drive_distance(float amount, float targetAngle);
  void drive_time(float duration, float speed);

  void control_arcade(float x, float y);
  void control_tank();

};
