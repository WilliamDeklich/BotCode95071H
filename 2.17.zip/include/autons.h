#pragma once

class Drive;

extern Drive chassis;

void auton1();

void auton2();

void auton3();

void auton4();