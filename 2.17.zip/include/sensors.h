float reduce_negative_180_to_180(float angle);

float reset_360(float angle);
