#include "vex.h"

// near

void auton1() { 
  chassis.drive_time(0.4, 40);
  wings.set(true);
  wait(0.4, sec);
  chassis.drive_time(0.4, -40);
  chassis.drive_time(0.75, 50);
  wings.set(false);
  wait(0.4, sec);
  chassis.turn_to_angle(42);
  intake.spin(reverse, 70, percent);
  wait(0.5, sec);
  intake.stop();
  chassis.turn_to_angle(180);
  chassis.drive_time(0.8, -40);
  chassis.drive_time(0.45, 40);
  chassis.turn_to_angle(300);
  chassis.drive_time(0.95, 50);
  chassis.turn_to_angle(320);
  intake.spin(reverse, 100, percent);
  chassis.drive_time(0.9, 50);
  wait(1, sec);
  intake.stop();
  chassis.drive_time(12, 0);
}

//far

void auton2() {
  wings.set(true);
  chassis.drive_time(0.6, -60);
  wings.set(false);
  wait(0.3, sec);
  chassis.turn_to_angle(315);
  chassis.drive_time(0.7, -70);
  chassis.drive_time(0.45, 50);
  chassis.turn_to_angle(104);
  intake.spin(forward, 100, percent);
  chassis.drive_time(1.1, 80);
  wait(0.4, sec);
  chassis.turn_to_angle(140);
  intake.stop();
  intake.spin(reverse, 100, percent);
  chassis.drive_time(0.35, 40);
  intake.stop();
  chassis.turn_to_angle(250);
  intake.spin(forward, 100, percent);
  chassis.drive_time(0.7, 60);
  wait(0.4, sec);
  wings.set(true);
  chassis.turn_to_angle(315);
  chassis.drive_time(0.9, -80);
  intake.stop();
  chassis.drive_time(0.3, 50);
  wings.set(false);
  chassis.turn_to_angle(180);
  chassis.drive_time(0.6, 80);
  chassis.drive_time(0.5, -80);
}

//near elims

void auton3() {
  chassis.drive_time(0.8, 85);
  chassis.turn_to_angle(270);
  wait(0.3, sec);
  wings.set(true);
  chassis.drive_time(0.8, -70);
  wait(0.3, sec);
  wings.set(false);
  chassis.drive_time(0.8, 70);
  intake.spin(reverse, 70, percent);
  wait(0.5, sec);
  intake.stop();
  chassis.turn_to_angle(180);
  chassis.drive_time(0.7, -50);
  chassis.drive_time(0.5, 50);
}

//skills

void auton4() {
  chassis.drive_time(0.7, -60);
  chassis.turn_to_angle(45);
  chassis.drive_time(0.5, -60);
  chassis.drive_time(0.38, 60);
  chassis.turn_to_angle(70);
  cata.spin(reverse, 100, percent);
  wait(3, sec);
  catapos(330);
  chassis.turn_to_angle(57);
  chassis.drive_time(0.9, -55);
  chassis.turn_to_angle(323);
  chassis.drive_time(1.5, -81);
  chassis.turn_to_angle(315);

  chassis.drive_time(0.7, -60);
  chassis.turn_to_angle(310);
  chassis.drive_time(0.5, -60);
  chassis.drive_time(0.6, 60);

  chassis.drive_time(1, -60);
  chassis.drive_time(0.33, 60);
  chassis.turn_to_angle(290);
  chassis.drive_time(1, -80);
  chassis.turn_to_angle(125);
  wings.set(true);
  chassis.drive_time(1, -80);
  chassis.drive_time(0.5, 80);
  wings.set(false);
  chassis.turn_to_angle(90);
  chassis.drive_time(0.882745, 80);
  wings.set(true);
  chassis.turn_to_angle(310);

  chassis.drive_time(1, -80);
  chassis.drive_time(0.3, 80);
  wings.set(false);
  chassis.drive_time(0.5, 80);
  chassis.turn_to_angle(360);
  wings.set(true);
  chassis.drive_time(1, -80);
  chassis.drive_time(0.3, 80);
  wings.set(false);
}