#include "vex.h"

Drive::Drive(float wheel_diameter, float wheel_ratio) :
  wheel_diameter(wheel_diameter),
  wheel_ratio(wheel_ratio),
  drive_in_to_deg_ratio(wheel_ratio/360 * 3.14159 * wheel_diameter) 
{};

float Drive::left_position() {
  return(lm.position(degrees) * drive_in_to_deg_ratio);
}

float Drive::right_position() {
  return(rm.position(degrees) * drive_in_to_deg_ratio);
}

void Drive::turn_to_angle(float targetAngle) {

/*
  Inertial.setHeading(0, degrees);

  PID turnPID(reduce_negative_180_to_180(targetAngle - Inertial.heading(degrees)), 0.53, 0.01, 0.45, 15, 1, 40, 2000);

  while(turnPID.is_settled() == false){

    float error = reduce_negative_180_to_180(targetAngle - Inertial.heading(degrees));
    float output = turnPID.compute(error);

    lf.spin(forward, output, percent);
    lm.spin(forward, output, percent);
    lb.spin(forward, output, percent);
    rf.spin(reverse, output, percent);
    rm.spin(reverse, output, percent);
    rb.spin(reverse, output, percent);

    wait(20, msec); 
  }
  
  lf.stop();
  lm.stop();
  lb.stop();
  rf.stop();
  rm.stop();
  rb.stop();
}
*/

   
  Inertial.setHeading(0, degrees);

  float kp = 0.53; 
  float ki = 0.01;
  float kd = 0.45;
  float starti = 15;
  float settle_error = 1; 
  float settle_time = 40.0; 
  float timeout = 1500;
  float error = 0;
  float accumulated_error = 0;
  float previous_error = 0;
  float output = 0;
  float time_spent_settled = 0;
  float time_spent_running = 0;


  float currentAngle = 0;

  while (true) {

    currentAngle = Inertial.heading(degrees);

    error = targetAngle - currentAngle;
        
    if (error > 180) {
      error -= 360;
    }
    if (error < -180) {
      error += 360;
    }

    if (fabs(error) < starti) {
      accumulated_error += error;
    }
    if ((error > 0 && previous_error < 0) || (error < 0 && previous_error > 0)) {
      accumulated_error = 0;
    }

    output = kp * error + ki * accumulated_error + kd * (error - previous_error);
    previous_error = error;

    if (fabs(error) < settle_error) {
      time_spent_settled += 20;
    } else {
      time_spent_settled = 0;
    }

    time_spent_running += 20;

    lf.spin(forward, output, percent);
    lm.spin(forward, output, percent);
    lb.spin(forward, output, percent);
    rf.spin(reverse, output, percent);
    rm.spin(reverse, output, percent);
    rb.spin(reverse, output, percent);

    if (time_spent_running > timeout || time_spent_settled > settle_time) {
      break; 
    }

    wait(20, msec); 
        
    }

  lf.stop();
  lm.stop();
  lb.stop();
  rf.stop();
  rm.stop();
  rb.stop();
}



void Drive::drive_distance(float inches, float targetAngle) {

  Inertial.setHeading(0, degrees);

  PID drivePID(inches, 1.5, 0, 0, 0, 1.5, 40, 10000);
  PID headingPID(reduce_negative_180_to_180(targetAngle - Inertial.heading(degrees)), 0.3, 0.01, 0, 0, 1, 40, 2000);

  float start_average_position = (left_position() + right_position())/2;
  float average_position = start_average_position;
  
  while(drivePID.is_settled() == false){
    
    average_position = (left_position() + right_position())/2;
    
    float drive_error = inches + start_average_position - average_position;
    float heading_error = reduce_negative_180_to_180(targetAngle - Inertial.heading(degrees));
    float drive_output = drivePID.compute(drive_error);
    float heading_output = headingPID.compute(heading_error);

    lf.spin(forward, drive_output + heading_output, percent);
    lm.spin(forward, drive_output + heading_output, percent);
    lb.spin(forward, drive_output + heading_output, percent);
    rf.spin(forward, drive_output - heading_output, percent);
    rm.spin(forward, drive_output - heading_output, percent);
    rb.spin(forward, drive_output - heading_output, percent);
    
    wait(20, msec);

  }

  lf.stop();
  lm.stop();
  lb.stop();
  rf.stop();
  rm.stop();
  rb.stop();
}

void Drive::drive_time(float duration, float speed) {
  
  Inertial.setHeading(0, degrees);

  float time_spent_running = 0;
  float error = 0;
  float accumulated_error = 0;
  float rspeed = speed;
  float lspeed = speed;
  float kP = 0.3;
  float kI = 0.01;

  while (time_spent_running <= (duration*1000)) {

    error = Inertial.heading(degrees);

    if (Inertial.heading(degrees) > 180) {
      error -= 360;
    }

    accumulated_error += error;

    rspeed = speed + (kP*error+kI*accumulated_error);
    lspeed = speed - (kP*error+kI*accumulated_error);

    time_spent_running += 20;

    rf.spin(forward, rspeed, percent);
    rm.spin(forward, rspeed, percent);
    rb.spin(forward, rspeed, percent);
    lf.spin(forward, lspeed, percent);
    lm.spin(forward, lspeed, percent);
    lb.spin(forward, lspeed, percent);

    wait(20, msec); 

  }
  
  rf.stop();
  rm.stop();
  rb.stop();
  lf.stop();
  lm.stop();
  lb.stop();
}


void Drive::control_arcade(float x,float y) {
  double rightspeed = (Controller1.Axis3.position() * y) + (Controller1.Axis1.position() * -x);
  double leftspeed = (Controller1.Axis3.position() * y) - (Controller1.Axis1.position() * -x);
  lf.setVelocity(leftspeed,percent);
  lm.setVelocity(leftspeed,percent);
  lb.setVelocity(leftspeed,percent);
  rf.setVelocity(rightspeed,percent);
  rm.setVelocity(rightspeed,percent);
  rb.setVelocity(rightspeed,percent);
  lf.spin(forward);
  lm.spin(forward);
  lb.spin(forward);
  rf.spin(forward);
  rm.spin(forward);
  rb.spin(forward);
}

void Drive::control_tank() {
  double rightspeed = Controller1.Axis2.position();
  double leftspeed = Controller1.Axis3.position();
  lf.setVelocity(leftspeed,percent);
  lm.setVelocity(leftspeed,percent);
  lb.setVelocity(leftspeed,percent);
  rf.setVelocity(rightspeed,percent);
  rm.setVelocity(rightspeed,percent);
  rb.setVelocity(rightspeed,percent);
  lf.spin(forward);
  lm.spin(forward);
  lb.spin(forward);
  rf.spin(forward);
  rm.spin(forward);
  rb.spin(forward);
}

