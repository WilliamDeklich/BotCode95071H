float reduce_negative_180_to_180(float targetAngle);

float reset_360(float targetAngle);

float limit_output(float output, float target);
