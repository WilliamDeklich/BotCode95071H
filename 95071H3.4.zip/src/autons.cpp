#include "vex.h"

// near

void auton1() { 
  chassis.drive_time(0.4, 50);
  wings.set(true);
  wait(0.3, sec);
  chassis.drive_time(0.6, -50);
  wings.set(false);
  chassis.turn_to_angle(130);
  intake.spin(reverse, 100, percent);
  chassis.drive_distance(35);
  intake.stop();
}

//far

void auton2() {
  //wings.set(true);
  chassis.drive_time(0.65, -60);
  //wings.set(false);
  wait(0.4, sec);
  chassis.turn_to_angle(315);
  chassis.drive_time(0.5, - 70);
  chassis.drive_distance(6);
  chassis.turn_to_angle(95);
  chassis.drive_distance(20);
  chassis.turn_to_angle(30);
  chassis.drive_distance(32);
  wait(0.4, sec);
  chassis.turn_to_angle(140);
  intake.stop();
  intake.spin(reverse, 100, percent);
  chassis.drive_distance(15);
  intake.stop();
  chassis.turn_to_angle(270);
  intake.spin(forward, 100, percent);
  chassis.drive_distance(22);
  wait(0.4, sec);
  chassis.turn_to_angle(320);
  //wings.set(true);
  chassis.drive_time(0.9, -80);
  intake.stop();
  chassis.drive_time(0.3, 60);
  //wings.set(false);
  chassis.turn_to_angle(180);
  chassis.drive_time(0.6, 80);
  chassis.drive_time(0.3, -80);
}

//near elims

void auton3() {
  chassis.drive_distance(43);
  chassis.turn_to_angle(270);
  intake.spin(reverse, 100, percent);
  wait(0.4, sec);
  intake.stop();
  wings.set(true);
  chassis.drive_distance(-25);
  wings.set(false);
  chassis.drive_distance(21);
  chassis.turn_to_angle(270);
  chassis.drive_distance(47);
  chassis.turn_to_angle(270);
  chassis.drive_distance(22);
  chassis.drive_distance(-30);
}

//skills

void auton4() {
  chassis.drive_time(0.3, -30);
  chassis.turn_to_angle(115);
  chassis.drive_time(0.2, 20);
  cata.spin(reverse, 100, percent);
  wait(30, sec);
  catapos(330);
  //chassis.turn_to_angle(58);
  chassis.turn_to_angle(65);
  //chassis.drive_time(0.8, -65);//-40
  chassis.drive_distance(-20);
  chassis.turn_to_angle(305);
  chassis.drive_distance(-78);
  chassis.turn_to_angle(317);
  chassis.drive_time(0.8, -60);
  chassis.turn_to_angle(315);
  chassis.drive_time(0.7, -80);
  chassis.drive_distance(9.5);
  chassis.turn_to_angle(294);
  chassis.drive_time(0.9, -80);
  chassis.turn_to_angle(135);
  wings.set(true);
  chassis.drive_time(1, -100);
  chassis.drive_time(0.5, 80);
  wings.set(false);
  chassis.turn_to_angle(90);
  chassis.drive_time(0.6, 80);
  wings.set(true);
  chassis.turn_to_angle(310);
  chassis.drive_time(1, -100);
  chassis.drive_time(0.2, 30);
  wings.set(false);
  chassis.turn_to_angle(90);
  chassis.drive_distance(54);
  chassis.turn_to_angle(315);
  chassis.drive_time(0.8, -60);
  chassis.turn_to_angle(45);
  chassis.drive_time(0.7, -80);
  chassis.drive_time(0.3, 50);

}

void macro() {
  chassis.drive_time(0.3, -30);
  chassis.turn_to_angle(115);
  chassis.drive_time(0.2, 20);
  Controller1.Screen.clearScreen();
  Controller1.Screen.print("Macro complete");
}
