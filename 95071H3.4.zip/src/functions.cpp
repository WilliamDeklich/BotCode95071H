#include "vex.h"

void catapos(float targetAngle) {

  float error = targetAngle - reset_360(Rotation.position(degrees));
  float timeout = 2000;
  float time_spent_running = 0;

  cata.stop();
  cata.spin(reverse, 100, percent);

  while (fabs(error) >= 10) {

    wait(20, msec);

    error = targetAngle - reset_360(Rotation.position(degrees));
    time_spent_running += 20;

    if (time_spent_running > timeout ) {
      break;
    }

  }
  cata.stop();
}