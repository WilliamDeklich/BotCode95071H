#include "vex.h"

float reduce_negative_180_to_180(float targetAngle) {
  if (targetAngle > 180) {
    targetAngle -= 360;
  }
  if (targetAngle < -180) {
    targetAngle += 360;
  }
  return(targetAngle);
}

float reset_360(float targetAngle) {
  if (targetAngle < 200) {
    targetAngle += 360;
  }
  return(targetAngle);
}

float limit_output(float output, float target) {
  if (output > target) {
    output = target;
  }
  if (output < -target) {
    output = -target;
  }
  return(output);
}

