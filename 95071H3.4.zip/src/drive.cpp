#include "vex.h"

Drive::Drive(float wheel_diameter, float wheel_ratio) :
  wheel_diameter(wheel_diameter),
  wheel_ratio(wheel_ratio),
  drive_in_to_deg_ratio(wheel_ratio/360 * 3.14159 * wheel_diameter)
{};

float Drive::left_position() {
  return(lb.position(degrees) * drive_in_to_deg_ratio);
}

float Drive::right_position() {
  return(rb.position(degrees) * drive_in_to_deg_ratio);
}
/*
void Drive::turn_to_angle(float targetAngle) {
  
  Inertial.setHeading(0, degrees);

  float angle_error[1024];
  float heading_control[1024];
  char fileHead[20] = "\n";
  char mybuffer[70];
  int i;
  int index = 0;
  
  PID turnPID(reduce_negative_180_to_180(targetAngle - Inertial.heading(degrees)), 0.45, 0, 2, 0, 1, 80, 2000);

  for(i=0;i<1024;i++) {
    angle_error[i] = 9999;
    heading_control[i] = 9999;
  }

  while(turnPID.is_settled() == false) {

    float error = reduce_negative_180_to_180(targetAngle - Inertial.heading(degrees));
    float output = turnPID.compute(error);

    lf.spin(forward, output, percent);
    lm.spin(forward, output, percent);
    lb.spin(forward, output, percent);
    rf.spin(reverse, output, percent);
    rm.spin(reverse, output, percent);
    rb.spin(reverse, output, percent);

    wait(20, msec); 

    Controller1.Screen.clearScreen();
    Controller1.Screen.setCursor(1, 1);
    Controller1.Screen.print(error);
    Controller1.Screen.setCursor(2, 1);
    Controller1.Screen.print(output);
    
    angle_error[index] = error;
    heading_control[index] = output;
    index += 1;
    
  }
  
  lf.stop();
  lm.stop();
  lb.stop();
  rf.stop();
  rm.stop();
  rb.stop();

 Brain.SDcard.savefile("turn_info10.txt", (uint8_t*)fileHead, 20);
  
  for(i=0;i<1024;i++) {
    sprintf(mybuffer, "%.4f, %.4f \n", angle_error[i], heading_control[i]);
    Brain.SDcard.appendfile("turn_info10.txt",(uint8_t*)mybuffer, strlen(mybuffer));
  } 
}
*/


void Drive::turn_to_angle(float targetAngle) {
   
  Inertial.setHeading(0, degrees);

  /*
  float angle_error[256];
  float heading_control[256];
  float accumError[256];
  float KP[256];
  char fileHead[20] = "\n";
  char mybuffer[70];
  int i;
  int index = 0;

  for(i=0;i<256;i++) {
    angle_error[i] = 9999;
    heading_control[i] = 9999;
    accumError[i] = 9999;
    KP[i] = 9999;
  }
  */

  float kp = 0.6; 
  float ki = 0; 
  float kd = 3;
  float starti = 15;
  float startd = 0;
  float settle_error = 1.5; 
  float settle_time = 40.0;
  float timeout = 1500;
  float error = 0;
  float accumulated_error = 0;
  float previous_error = 0;
  float output = 0;
  float time_spent_settled = 0;
  float time_spent_running = 0;

  /*
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1,1);
  Controller1.Screen.print(Inertial.heading(degrees));
  */

  while (true) {

    error = reduce_negative_180_to_180(targetAngle - Inertial.heading(degrees));

    if (fabs(error) < starti) {
      accumulated_error += error;
    }
    
    /*
    if (fabs(error) > startd) {
      previous_error = error;
    }
    */
    
    
    if ((error > 0 && previous_error < 0) || (error < 0 && previous_error > 0)) {
      accumulated_error = 0;
    }
    
    output = limit_output(kp * error + ki * accumulated_error + kd * (error - previous_error), 100);

    previous_error = error;

    if (fabs(error) < settle_error) {
      time_spent_settled += 20;
    } else {
      time_spent_settled = 0;
    }

    time_spent_running += 20;

    lf.spin(forward, output, percent);
    rf.spin(reverse, output, percent);
    lm.spin(forward, output, percent);
    rm.spin(reverse, output, percent);
    lb.spin(forward, output, percent);
    rb.spin(reverse, output, percent);

    if (time_spent_running > timeout || time_spent_settled > settle_time) {
      break; 
    }

    wait(20, msec); 

    /*
    angle_error[index] = error;
    heading_control[index] = output;
    accumError[index] = accumulated_error;
    index += 1;
    */
        
  }

  lf.stop();
  rf.stop();
  lm.stop();
  rm.stop();
  lb.stop();
  rb.stop();

  
  
  Controller1.Screen.setCursor(2,1);
  Controller1.Screen.print(error);
  Controller1.Screen.setCursor(3,1);
  Controller1.Screen.print(time_spent_running);
  
  
  

  /*
  sprintf(mybuffer, "%.4f, %.4f %.4f \n", kp, ki, kd );
  Brain.SDcard.savefile("turn_info.txt",(uint8_t*)mybuffer, strlen(mybuffer));
  
  for(i=0;i<1024;i++) {
    sprintf(mybuffer, "%.4f, %.4f %.4f %.4f \n", angle_error[i], heading_control[i], accumError[i]);
    Brain.SDcard.appendfile("turn_info.txt",(uint8_t*)mybuffer, strlen(mybuffer));
  }
  */
}

void Drive::drive_distance(float inches) {

  /*
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1,1);
  */
  

  Inertial.setHeading(0, degrees);
  lb.setPosition(0, degrees);
  rb.setPosition(0, degrees);
  
  /*
  float distance_error[1024];
  float angle_error[1024];
  float drive_control[1024];
  float heading_control[1024];
  char fileHead[20] = "\n";
  char mybuffer[70];
  int i;
  int index = 0;
  */
  /*
  int index = 0;
  float targetPosition[] = {0.0192,
    0.0768,
    0.1728,
    0.3072,
    0.4800,
    0.6912,
    0.9408,
    1.2288,
    1.5552,
    1.9200,
    2.3232,
    2.7648,
    3.2448,
    3.7632,
    4.3200,
    4.9152,
    5.5488,
    6.2208,
    6.9312,
    7.6800,
    8.4672,
    9.2928,
   10.1568,
   11.0592,
   12.0000,
   12.9408,
   13.8432,
   14.7072,
   15.5328,
   16.3200,
   17.0688,
   17.7792,
   18.4512,
   19.0848,
   19.6800,
   20.2368,
   20.7552,
   21.2352,
   21.6768,
   22.0800,
   22.4448,
   22.7712,
   23.0592,
   23.3088,
   23.5200,
   23.6928,
   23.8272,
   23.9232,
   23.9808,
   24.0000};
   */
  PID drivePID(inches, 3.5, 0, 0, 0, 1.5, 80, 10000);
  PID headingPID(reduce_negative_180_to_180(Inertial.heading(degrees)), 0.5, 0.01, 0, 15, 1, 40, 10000);
  
  /*
  for(i=0;i<1024;i++) {
     distance_error[i] = 9999;
     angle_error[i] = 9999;
     drive_control[i] = 9999;
     heading_control[i] = 9999;
  }
  */

  //float time_running = 0;

  while(drivePID.is_settled() == false) {
    
    //inches = targetPosition[index];
    float average_position = (left_position() + right_position())/2;
  
    float drive_error = inches - average_position;
    float heading_error = reduce_negative_180_to_180(Inertial.heading(degrees));
    float drive_output = limit_output(drivePID.compute(drive_error), 100);
    float heading_output = limit_output(headingPID.compute(heading_error), 10);

    lf.spin(forward, drive_output - heading_output, percent);
    rf.spin(forward, drive_output + heading_output, percent);
    lm.spin(forward, drive_output - heading_output, percent);
    rm.spin(forward, drive_output + heading_output, percent);
    lb.spin(forward, drive_output - heading_output, percent);
    rb.spin(forward, drive_output + heading_output, percent);
    
    wait(20, msec);

    /*
    Controller1.Screen.clearScreen();
    Controller1.Screen.setCursor(1,1);
    Controller1.Screen.print(index);
    */
    /*
    distance_error[index] = drive_error;
    angle_error[index] = heading_error;
    drive_control[index] = drive_output;
    heading_control[index] = heading_output;
    index += 1;
    */
    
    //time_running += 20;
    //index+=1;
  }

  lf.stop();
  lm.stop();
  lb.stop();
  rf.stop();
  rm.stop();
  rb.stop();
  
  //Controller1.Screen.print(time_running);

  /*
  Brain.SDcard.savefile("drive_info_small.txt", (uint8_t*)fileHead, 20);
  
  for(i=0;i<1024;i++) {
    sprintf(mybuffer, "%.4f, %.4f, %.4f, %.4f \n", distance_error[i], angle_error[i], drive_control[i], heading_control[i]);
    Brain.SDcard.appendfile("drive_info_small.txt",(uint8_t*)mybuffer, strlen(mybuffer));
  }
  */
}

void Drive::drive_time(float duration, float speed) {

  float time_spent_running = 0;

  while (time_spent_running <= (duration*1000)) {

    lf.spin(forward, speed, percent);
    rf.spin(forward, speed, percent);
    lm.spin(forward, speed, percent);
    rm.spin(forward, speed, percent);
    lb.spin(forward, speed, percent);
    rb.spin(forward, speed, percent);

    time_spent_running += 20;

    wait(20, msec); 

  }

  lf.stop();
  rf.stop();
  lm.stop();
  rm.stop();
  lb.stop();
  rb.stop();
}

void Drive::control_arcade(float x,float y) {
  double rightspeed = (Controller1.Axis3.position() * y) + (Controller1.Axis1.position() * -x);
  double leftspeed = (Controller1.Axis3.position() * y) - (Controller1.Axis1.position() * -x);
  lf.setVelocity(leftspeed,percent);
  lm.setVelocity(leftspeed,percent);
  lb.setVelocity(leftspeed,percent);
  rf.setVelocity(rightspeed,percent);
  rm.setVelocity(rightspeed,percent);
  rb.setVelocity(rightspeed,percent);
  lf.spin(forward);
  rf.spin(forward);
  lm.spin(forward);
  rm.spin(forward);
  lb.spin(forward);
  rb.spin(forward);
}

void Drive::control_tank() {
  double rightspeed = Controller1.Axis2.position();
  double leftspeed = Controller1.Axis3.position();
  lf.setVelocity(leftspeed,percent);
  lm.setVelocity(leftspeed,percent);
  lb.setVelocity(leftspeed,percent);
  rf.setVelocity(rightspeed,percent);
  rm.setVelocity(rightspeed,percent);
  rb.setVelocity(rightspeed,percent);
  lf.spin(forward);
  rf.spin(forward);
  lm.spin(forward);
  rm.spin(forward);
  lb.spin(forward);
  rb.spin(forward);
}

