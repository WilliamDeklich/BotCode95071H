/*----------------------------------------------------------------------------*/
/* */
/* Module: main.cpp */
/* Author: VEX */
/* Created: Thu Sep 26 2019 */
/* Description: Competition Template */
/* */
/*----------------------------------------------------------------------------*/




// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// intake               motor         20              
// cata                 motor         11              
// rb                   motor         5               
// rt                   motor         3               
// rf                   motor         1               
// lf                   motor         2               
// lb                   motor         6               
// lt                   motor         4               
// LeftWing             digital_out   G               
// RightWing            digital_out   H               
// HangMech             digital_out   D               
// Inertial7            inertial      7               
// blocker1             digital_out   F               
// blocker2             digital_out   E               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

competition Competition;


bool toggle = false; 
bool latch = false;
bool toggle2 = false; 
bool latch2 = false;
bool toggle3 = false; 
bool latch3 = false;
bool toggle4 = false; 
bool latch4 = false;
bool selected = true;

void turn_to_angle(float targetAngle) {
    // Initialize PID constants and variables
    Inertial7.setHeading(0, degrees);
    float kp = 0.4; // Replace with your PID constants
    float ki = 0.02;
    float kd = 0.02;
    float starti = 0.1;
    float settle_error = 1.0; // Replace with a suitable settle_error for your system
    float settle_time = 100.0; // Replace with a suitable settle_time for your system
    float timeout = 5000.0; // Timeout to prevent infinite loop if unable to settle

    // Initialize variables for PID control
    float accumulated_error = 0;
    float previous_error = 0;
    float output = 0;
    float time_spent_settled = 0;
    float time_spent_running = 0;

    // Initialize current angle as 0 (assuming the gyro sensor measures angles)
    float currentAngle = 0;

    // Loop until the system settles or times out
    while (true) {
        // Read the current angle from the gyro sensor
        currentAngle = Inertial7.heading(degrees);

        // Calculate the error (difference between target and current angles)
        float error = targetAngle - currentAngle;

        // PID calculation
        if (fabs(error) < starti) {
            accumulated_error += error;
        }

        if ((error > 0 && previous_error < 0) || (error < 0 && previous_error > 0)) {
            accumulated_error = 0;
        }

        output = kp * error + ki * accumulated_error + kd * (error - previous_error);
        previous_error = error;

        if (fabs(error) < settle_error) {
            time_spent_settled += 10;
        } else {
            time_spent_settled = 0;
        }

        time_spent_running += 10;

        // Apply control output to the motor
        lf.spin(forward, output, percent);
        lt.spin(forward, output, percent);
        lb.spin(forward, output, percent);
        rf.spin(reverse, output, percent);
        rt.spin(reverse, output, percent);
        rb.spin(reverse, output, percent);

        // Check if settled or timed out
        if (time_spent_running > timeout || time_spent_settled > settle_time) {
            break; // Exit the loop if settled or timed out
        }

        wait(20, msec); // Adjust delay as needed
        /*
        Controller1.Screen.clearScreen();
        Controller1.Screen.setCursor(1,1);
        Controller1.Screen.print("Inertial Heading : %f, ", Inertial7.heading(degrees));
        Controller1.Screen.setCursor(2,1);
        Controller1.Screen.print("Time Spent Settled : %f, ", time_spent_settled);
        Controller1.Screen.setCursor(3,1);
        Controller1.Screen.print("Time Spent : %f, ", time_spent_running);
        */
    }

    // Stop the motor after reaching the target angle or timeout
    lf.stop();
    lt.stop();
    lb.stop();
    rf.stop();
    rt.stop();
    rb.stop();
}

void Forward(double duration, int speed) {
    
    rf.spin(forward, speed, percent);
    rt.spin(forward, speed, percent);
    rb.spin(forward, speed, percent);
    lf.spin(forward, speed, percent);
    lt.spin(forward, speed, percent);
    lb.spin(forward, speed, percent);

    double stopTime = Brain.timer(vex::timeUnits::sec) + duration;

    while (Brain.timer(vex::timeUnits::sec) < stopTime) {
    }

    rf.stop();
    rt.stop();
    rb.stop();
    lf.stop();
    lt.stop();
    lb.stop();
}


void Backward(double duration, int speed) {
    
    rf.spin(reverse, speed, percent);
    rt.spin(reverse, speed, percent);
    rb.spin(reverse, speed, percent);
    lf.spin(reverse, speed, percent);
    lt.spin(reverse, speed, percent);
    lb.spin(reverse, speed, percent);

    double stopTime = Brain.timer(vex::timeUnits::sec) + duration;

    while (Brain.timer(vex::timeUnits::sec) < stopTime) {
    }

    
    rf.stop();
    rt.stop();
    rb.stop();
    lf.stop();
    lt.stop();
    lb.stop();
}

void TurnRight(double duration) {
    int speed = 20;  
    
    lf.spin(forward, speed, percent);
    lt.spin(forward, speed, percent);
    lb.spin(forward, speed, percent);

    double stopTime = Brain.timer(vex::timeUnits::sec) + duration;

    while (Brain.timer(vex::timeUnits::sec) < stopTime) {

    }

    lf.stop();
    lt.stop();
    lb.stop();
}
void FullRight(double duration) {
    int speed = 20;  
    
    lf.spin(forward, speed, percent);
    lt.spin(forward, speed, percent);
    lb.spin(forward, speed, percent);
    rf.spin(reverse, speed, percent);
    rt.spin(reverse, speed, percent);
    rb.spin(reverse, speed, percent);

    double stopTime = Brain.timer(vex::timeUnits::sec) + duration;

    while (Brain.timer(vex::timeUnits::sec) < stopTime) {

    }

    lf.stop();
    lt.stop();
    lb.stop();
}
void TurnLeft(double duration) {
    int speed = 20;  
    
   
    rf.spin(forward, speed, percent);
    rt.spin(forward, speed, percent);
    rb.spin(forward, speed, percent);
    
    double stopTime = Brain.timer(vex::timeUnits::sec) + duration;

    while (Brain.timer(vex::timeUnits::sec) < stopTime) {
    }
    rf.stop();
    rt.stop();
    rb.stop();
    
}
void FullLeft(double duration) {
    int speed = 20;  
    
   
    rf.spin(forward, speed, percent);
    rt.spin(forward, speed, percent);
    rb.spin(forward, speed, percent);
    lf.spin(reverse, speed, percent);
    lt.spin(reverse, speed, percent);
    lb.spin(reverse, speed, percent);
    
    double stopTime = Brain.timer(vex::timeUnits::sec) + duration;

    while (Brain.timer(vex::timeUnits::sec) < stopTime) {
    }
    rf.stop();
    rt.stop();
    rb.stop();
    
}
int auton = 1;
int noa = 3;
void autonselector() {
 if (auton>noa){
   auton=1;
 }
if (auton<1){
   auton=noa;
}
if(Controller1.Axis1.position(percent) > 5){
   auton++;
   wait(0.5,seconds);
}
if(Controller1.Axis1.position(percent) < -5){
   auton--;
   wait(0.5,seconds);
}
if(auton == 1){
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1,1);
  Controller1.Screen.print("Far");
}
if(auton == 2){
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1,1);
  Controller1.Screen.print("Near");
  }
if(auton == 3){
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1,1);
  Controller1.Screen.print("Skills");
  }  
}

void dtCode(double x,double y) {
  double rightspeed = (Controller1.Axis3.position() * y) + (Controller1.Axis4.position() * -x);
  double leftspeed = (Controller1.Axis3.position() * y) - (Controller1.Axis4.position() * -x);
  lf.setVelocity(leftspeed,percent);
  lb.setVelocity(leftspeed,percent);
  lt.setVelocity(leftspeed,percent);
  rf.setVelocity(rightspeed,percent);
  rb.setVelocity(rightspeed,percent);
  rt.setVelocity(rightspeed,percent);
  lf.spin(forward);
  lb.spin(forward);
  lt.spin(forward);
  rf.spin(forward);
  rb.spin(forward);
  rt.spin(forward);
}

/*void auton1(){
  Forward(1.6,50);
  FullRight(0.8);
  Forward(1,40);
  Backward(0.4,50);
  //RightWing.set(false); 
  FullLeft(1.8);
  Forward(0.8,50);
  FullRight(0.7);
  intake.spin(reverse,100, percent);
  Forward(0.7,15);
  Forward(0.2,20);
  wait(0.7, seconds);
  //Lef.set(true);
  //Backward(0.4,50);
  Backward(0.5,12);
  intake.stop();
  FullRight(0.5);
  RightWing.set(true);
  FullRight(0.6);
  Forward(1.8,50);
  Backward(0.5,50);
  Forward(0.5,30);
} 

void auton2(){
  Forward(1.6,50);
  FullLeft(0.8);
  Forward(1,40);
  Backward(0.4,50);
  //RightWing.set(false); 
  FullRight(1.3);
  intake.spin(reverse,100, percent);
  Forward(0.6,15);
  Forward(0.1,15);
  wait(0.7, seconds);
  //Backward(0.4,50);
  Backward(0.5,12);
  intake.stop();
  FullRight(1.2);
  Forward(1.8,50);
  FullLeft(0.85);
  Forward(1,55);
  intake.spin(forward, 100, percent);
  wait(2, seconds);
  intake.stop();

}
void auton3(){

  cata.spin(reverse, 90, percent);
  wait(35,seconds);
  Forward(0.5,30);
  FullRight(0.5);
  Forward(0.6,40);
  FullLeft(0.4);
  Forward(1,40);
  LeftWing.set(true);
  RightWing.set(true);
  FullLeft(0.4);
  Forward(0.8,80);
}

*/

void auton1(){
  wait(2,sec);
  turn_to_angle(90.0);
  wait(1,sec);
  turn_to_angle(180.0);
}

void pre_auton(void) {
  vexcodeInit();

}

void autonomous(void) {

  lf.setStopping(hold);
  lb.setStopping(hold);
  lt.setStopping(hold);
  rf.setStopping(hold);
  rb.setStopping(hold);
  rt.setStopping(hold);
  if (auton == 1){
  auton1();
  }
/*
  if (auton == 2){
  auton2();
  }
  if (auton == 3){
    auton3();
  }
*/
}

void usercontrol(void) {

  while (true){
    dtCode(0.3, 1);
    autonselector();
    lf.setStopping(brake);
    lb.setStopping(brake);
    lt.setStopping(coast);
    rf.setStopping(brake);
    rb.setStopping(brake);
    rt.setStopping(coast);

    //Intake
    if (Controller1.ButtonR1.pressing()){
      intake.spin(reverse,90,percent);
    }
    if (Controller1.ButtonR2.pressing()){
      intake.spin(forward,90,percent);
    }
    if(!Controller1.ButtonR2.pressing()&& !Controller1.ButtonR1.pressing()){
    intake.stop();
      }
    //HangMech
    if(Controller1.ButtonLeft.pressing() && (Controller1.ButtonRight.pressing())){
    HangMech.set(true);
      }
    //FlyWheel
    if (toggle2){
      cata.spin(reverse,100,percent); 
    } 
    else {
      cata.stop();
    }
    if (Controller1.ButtonA.pressing()) {
      if(!latch2){ 
        toggle2 = !toggle2;
        latch2 = true;
      }
    } 
    else {
      latch2 = false; 
    }
    //Blocker
    if (toggle4){
      blocker1.set(true);
      blocker2.set(true);
    } 
    else {
      blocker2.set(false);
      blocker1.set(false); 
    }

    if (Controller1.ButtonX.pressing()) {
      if(!latch4){ 
        toggle4 = !toggle4;
        latch4 = true;
      }
    } 
    else {
      latch4 = false; 
    }
    //Left Wing
    if (toggle){
      LeftWing.set(true);  
    } 
    else {
      LeftWing.set(false);
    }

    if (Controller1.ButtonL2.pressing()) {
      if(!latch){ 
        toggle = !toggle;
        latch = true;
      }
    } 
    else {
      latch = false; 
    }
    //Right Wing
    if (toggle3){
      RightWing.set(true); 
    } 
    else {
      
      RightWing.set(false); 
    }

    if (Controller1.ButtonL1.pressing()) {
      if(!latch3){ 
        toggle3 = !toggle3;
        latch3 = true;
      }
    } 
    else {
      latch3 = false; 
    }
  }
}


int main() {
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);
  pre_auton();
while (true) {
  
  wait(20,msec);
  }
}

