float reduce_negative_180_to_180(float targetAngle);

float reset_360(float targetAngle);

float limit_80(float target);

float limit_10(float target);

float limit_3(float target);
