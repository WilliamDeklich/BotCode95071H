#include "vex.h"

Drive::Drive(float wheel_diameter, float wheel_ratio) :
  wheel_diameter(wheel_diameter),
  wheel_ratio(wheel_ratio),
  drive_in_to_deg_ratio(wheel_ratio/360 * 3.14159 * wheel_diameter)
{};

float Drive::left_position() {
  return(lb.position(degrees) * drive_in_to_deg_ratio);
}

float Drive::right_position() {
  return(rb.position(degrees) * drive_in_to_deg_ratio);
}
/*
void Drive::turn_to_angle(float targetAngle) {
  
  Inertial.setHeading(0, degrees);

  
  float angle_error[1024];
  float heading_control[1024];
  char fileHead[20] = "\n";
  char mybuffer[70];
  int i;
  int index = 0;
  
  

  PID turnPID(reduce_negative_180_to_180(targetAngle - Inertial.heading(degrees)), 0.45, 0, 2, 0, 1, 80, 2000);

  
  for(i=0;i<1024;i++) {
    angle_error[i] = 9999;
    heading_control[i] = 9999;
  }
  
  

  while(turnPID.is_settled() == false) {

    float error = reduce_negative_180_to_180(targetAngle - Inertial.heading(degrees));
    float output = turnPID.compute(error);

    lf.spin(forward, output, percent);
    lm.spin(forward, output, percent);
    lb.spin(forward, output, percent);
    rf.spin(reverse, output, percent);
    rm.spin(reverse, output, percent);
    rb.spin(reverse, output, percent);

    wait(20, msec); 

   
    Controller1.Screen.clearScreen();
    Controller1.Screen.setCursor(1, 1);
    Controller1.Screen.print(error);
    Controller1.Screen.setCursor(2, 1);
    Controller1.Screen.print(output);
    

    
    angle_error[index] = error;
    heading_control[index] = output;
    index += 1;
    
    
  }
  
  lf.stop();
  lm.stop();
  lb.stop();
  rf.stop();
  rm.stop();
  rb.stop();

  
 Brain.SDcard.savefile("turn_info10.txt", (uint8_t*)fileHead, 20);
  
  for(i=0;i<1024;i++) {
    sprintf(mybuffer, "%.4f, %.4f \n", angle_error[i], heading_control[i]);
    Brain.SDcard.appendfile("turn_info10.txt",(uint8_t*)mybuffer, strlen(mybuffer));
  }
  

  
  
}
*/


void Drive::turn_to_angle(float targetAngle) {
   
  Inertial.setHeading(0, degrees);

  float angle_error[256];
  float heading_control[256];
  float accumError[256];
  char fileHead[20] = "\n";
  char mybuffer[70];
  int i;
  int index = 0;

  for(i=0;i<256;i++) {
    angle_error[i] = 9999;
    heading_control[i] = 9999;
    accumError[i] = 9999;
  }
  
  float kp = 0.65; //0.5
  float ki = 0.01; //0.01
  float kd = 3; //3
  float starti = 15;
  float settle_error = 1; 
  float settle_time = 40.0;
  float timeout = 1500;
  float error = 0;
  float accumulated_error = 0;
  float previous_error = 0;
  float output = 0;
  float time_spent_settled = 0;
  float time_spent_running = 0;

  while (true) {

    error = reduce_negative_180_to_180(targetAngle - Inertial.heading(degrees));

    if (fabs(error) < starti) {
      accumulated_error += error;
    }
    
    if ((error > 0 && previous_error < 0) || (error < 0 && previous_error > 0)) {
      accumulated_error = 0;
    }
    

    output = limit_80(kp * error + limit_3(ki * accumulated_error) + kd * (error - previous_error));
    previous_error = error;

    if (fabs(error) < settle_error) {
      time_spent_settled += 20;
    } else {
      time_spent_settled = 0;
    }

    time_spent_running += 20;


    lf.spin(forward, output, percent);
    lm.spin(forward, output, percent);
    lb.spin(forward, output, percent);
    rf.spin(reverse, output, percent);
    rm.spin(reverse, output, percent);
    rb.spin(reverse, output, percent);

    if (time_spent_running > timeout || time_spent_settled > settle_time) {
      break; 
    }

    wait(20, msec); 

    angle_error[index] = error;
    heading_control[index] = output;
    accumError[index] = accumulated_error;
    index += 1;
    
        
  }

  lf.stop();
  lm.stop();
  lb.stop();
  rf.stop();
  rm.stop();
  rb.stop();

  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1,1);
  Controller1.Screen.print(time_spent_running);
  Controller1.Screen.setCursor(2,1);
  Controller1.Screen.print(error);

  sprintf(mybuffer, "%.4f, %.4f %.4f \n", kp, ki, kd );
  Brain.SDcard.savefile("turn_info.txt",(uint8_t*)mybuffer, strlen(mybuffer));
  
  for(i=0;i<1024;i++) {
    sprintf(mybuffer, "%.4f, %.4f %.4f \n", angle_error[i], heading_control[i], accumError[i] );
    Brain.SDcard.appendfile("turn_info.txt",(uint8_t*)mybuffer, strlen(mybuffer));
  }
}

void Drive::drive_distance(float inches) {

  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1,1);

  Inertial.setHeading(0, degrees);
  lb.setPosition(0, degrees);
  rb.setPosition(0, degrees);
  
  
  float distance_error[1024];
  float angle_error[1024];
  float drive_control[1024];
  float heading_control[1024];
  char fileHead[20] = "\n";
  char mybuffer[70];
  int i;
  int index = 0;
  
  
  PID drivePID(inches, 4, 0, 0, 0, 0.5, 80, 10000);
  PID headingPID(reduce_negative_180_to_180(Inertial.heading(degrees)), 0.65, 0.01, 3, 15, 0, 40, 10000);
  
  for(i=0;i<1024;i++) {
     distance_error[i] = 9999;
     angle_error[i] = 9999;
     drive_control[i] = 9999;
     heading_control[i] = 9999;
  }
  
  float time_running = 0;

  while(drivePID.is_settled() == false) {
    
    float average_position = (left_position() + right_position())/2;
  
    float drive_error = inches - average_position;
    float heading_error = reduce_negative_180_to_180(Inertial.heading(degrees));
    float drive_output = limit_80(drivePID.compute(drive_error));
    float heading_output = limit_10(headingPID.compute(heading_error));

    lf.spin(forward, drive_output - heading_output, percent);
    lm.spin(forward, drive_output - heading_output, percent);
    lb.spin(forward, drive_output - heading_output, percent);
    rm.spin(forward, drive_output + heading_output, percent);
    rf.spin(forward, drive_output + heading_output, percent);
    rb.spin(forward, drive_output + heading_output, percent);
    
    wait(20, msec);
    
    
    distance_error[index] = drive_error;
    angle_error[index] = heading_error;
    drive_control[index] = drive_output;
    heading_control[index] = heading_output;
    index += 1;
    
    time_running += 20;
  }

  lf.stop();
  lm.stop();
  lb.stop();
  rf.stop();
  rm.stop();
  rb.stop();
  Controller1.Screen.print(time_running);

  
  Brain.SDcard.savefile("drive_info_small.txt", (uint8_t*)fileHead, 20);
  
  for(i=0;i<1024;i++) {
    sprintf(mybuffer, "%.4f, %.4f, %.4f, %.4f \n", distance_error[i], angle_error[i], drive_control[i], heading_control[i]);
    Brain.SDcard.appendfile("drive_info_small.txt",(uint8_t*)mybuffer, strlen(mybuffer));
  }
  

}


/*
void Drive::drive_distance(float inches, float speed) {

  Inertial.setHeading(0, degrees);

  float drive_kp = 3.5; 
  float drive_ki = 0;
  float drive_kd = 0;
  float drive_starti = 0;
  float drive_settle_error = 0.5; 
  float drive_settle_time = 40.0; 
  float drive_timeout = 10000;
  float drive_error = 0;
  float drive_accumulated_error = 0;
  float drive_previous_error = 0;
  float drive_output = 0;
  float drive_time_spent_settled = 0;
  float drive_time_spent_running = 0;

  float heading_kp = 0.5; 
  float heading_ki = 0;
  float heading_kd = 0;
  float heading_starti = 0;
  float heading_settle_error = 1; 
  float heading_settle_time = 40.0; 
  float heading_timeout = 10000;
  float heading_error = 0;
  float heading_accumulated_error = 0;
  float heading_previous_error = 0;
  float heading_output = 0;
  float heading_time_spent_settled = 0;
  float heading_time_spent_running = 0;

  float start_average_position = (left_position() + right_position())/2;
  float average_position = start_average_position;
  
  while (true) {

    average_position = (left_position() + right_position())/2;
    
    drive_error = inches + start_average_position - average_position;
    drive_output = speed;

    heading_error = reduce_negative_180_to_180(Inertial.heading(degrees));
    heading_output = limit_10(heading_output);
    
    if (fabs(drive_error) < drive_starti) {
      drive_accumulated_error += drive_error;
    }
    if ((drive_error > 0 && drive_previous_error < 0) || (drive_error < 0 && drive_previous_error > 0)) {
      drive_accumulated_error = 0;
    }

    if (fabs(drive_error) <= 12) {
      drive_output = drive_kp * drive_error + drive_ki * drive_accumulated_error + drive_kd * (drive_error - drive_previous_error);
    }

    drive_previous_error = drive_error;

    if (fabs(drive_error) < drive_settle_error) {
      drive_time_spent_settled += 20;
    } else {
      drive_time_spent_settled = 0;
    }

    drive_time_spent_running += 20;

    lf.spin(forward, drive_output, percent);
    lm.spin(forward, drive_output, percent);
    lb.spin(forward, drive_output, percent);
    rf.spin(forward, drive_output, percent);
    rm.spin(forward, drive_output, percent);
    rb.spin(forward, drive_output, percent);

    if (drive_time_spent_running > drive_timeout || drive_time_spent_settled > drive_settle_time) {
      break; 
    }

    wait(20, msec); 
        
  }

  lf.stop();
  lm.stop();
  lb.stop();
  rf.stop();
  rm.stop();
  rb.stop();
}
*/


void Drive::drive_time(float duration, float speed) {

  float time_spent_running = 0;

  while (time_spent_running <= (duration*1000)) {

    rf.spin(forward, speed, percent);
    rm.spin(forward, speed, percent);
    rb.spin(forward, speed, percent);
    lf.spin(forward, speed, percent);
    lm.spin(forward, speed, percent);
    lb.spin(forward, speed, percent);

    time_spent_running += 20;

    wait(20, msec); 

  }

  rf.stop();
  rm.stop();
  rb.stop();
  lf.stop();
  lm.stop();
  lb.stop();
}

void Drive::control_arcade(float x,float y) {
  double rightspeed = (Controller1.Axis3.position() * y) + (Controller1.Axis1.position() * -x);
  double leftspeed = (Controller1.Axis3.position() * y) - (Controller1.Axis1.position() * -x);
  lf.setVelocity(leftspeed,percent);
  lm.setVelocity(leftspeed,percent);
  lb.setVelocity(leftspeed,percent);
  rf.setVelocity(rightspeed,percent);
  rm.setVelocity(rightspeed,percent);
  rb.setVelocity(rightspeed,percent);
  lf.spin(forward);
  lm.spin(forward);
  lb.spin(forward);
  rf.spin(forward);
  rm.spin(forward);
  rb.spin(forward);
}

void Drive::control_tank() {
  double rightspeed = Controller1.Axis2.position();
  double leftspeed = Controller1.Axis3.position();
  lf.setVelocity(leftspeed,percent);
  lm.setVelocity(leftspeed,percent);
  lb.setVelocity(leftspeed,percent);
  rf.setVelocity(rightspeed,percent);
  rm.setVelocity(rightspeed,percent);
  rb.setVelocity(rightspeed,percent);
  lf.spin(forward);
  lm.spin(forward);
  lb.spin(forward);
  rf.spin(forward);
  rm.spin(forward);
  rb.spin(forward);
}

