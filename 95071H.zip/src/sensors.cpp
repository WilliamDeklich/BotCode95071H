#include "vex.h"

float reduce_negative_180_to_180(float targetAngle) {
  if (targetAngle > 180) {
    targetAngle -= 360;
  }
  if (targetAngle < -180) {
    targetAngle += 360;
  }
  return(targetAngle);
}

float reset_360(float targetAngle) {
  if (targetAngle < 200) {
    targetAngle += 360;
  }
  return(targetAngle);
}

float limit_80(float target) {
  if (target > 80) {
    target = 80;
  }
  if (target < -80) {
    target = -80;
  }
  return(target);
}

float limit_10(float target) {
  if (fabs(target) >= 10) {
    target = 0;
  }
  return(target);
}

float limit_3(float target) {
  if (target > 20) {
    target = 20;
  }
  if (target < -20) {
    target = -20;
  }
  return(target);
}

