/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       eric                                                      */
/*    Created:      Sat Dec 23 2023                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// rf                   motor         1               
// rm                   motor         2               
// rb                   motor         3               
// lf                   motor         4               
// lm                   motor         5               
// lb                   motor         6               
// cata                 motor         11              
// intake               motor         12              
// Inertial             inertial      7               
// Rotation             rotation      8               
// wings                digital_out   H               
// hang                 digital_out   G               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"


using namespace vex;

competition Competition;

Drive chassis(2.75, 0.75);

bool toggle = false; 
bool latch = false;
bool toggle2 = false; 
bool latch2 = false;
bool toggle3 = false; 
bool latch3 = false;

int auton = 1;
int noa = 4;
void autonselector() {
if (auton>noa){
  auton=1;
}
if (auton<1){
  auton=noa;
}
if(Controller1.ButtonA.pressing()){
  auton++;
}

if(auton == 1){
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1,1);
  Controller1.Screen.print("Near");
}
if(auton == 2){
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1,1);
  Controller1.Screen.print("Far");
  }
if(auton == 3){
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1,1);
  Controller1.Screen.print("NearElims");
  }  
if(auton == 4){
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1,1);
  Controller1.Screen.print("Skills");
  }  
}

void pre_auton(void) {
  vexcodeInit();
}

void autonomous(void) {

  lf.setStopping(hold);
  lm.setStopping(hold);
  lb.setStopping(hold);
  rf.setStopping(hold);
  rm.setStopping(hold);
  rb.setStopping(hold);
  
  if (auton == 1){
    auton1();
  }

   if (auton == 2){
    auton2();
  }
  if (auton == 3){
    auton3();
  }

   if (auton == 4){
    auton4();
  }
}


void usercontrol(void) {
  
  while (true){
    //chassis.control_tank();
    chassis.control_arcade(0.55, 1);
    autonselector();
    lf.setStopping(coast);
    lm.setStopping(brake);
    lb.setStopping(coast);
    rf.setStopping(coast);
    rm.setStopping(brake);
    rb.setStopping(coast);

    //auton tester 
   
    if (Controller1.ButtonDown.pressing()){
      wait(2, sec);
      chassis.turn_to_angle(30);

      wait(5, sec);
    }

    // intake

    if (Controller1.ButtonR1.pressing()){
      intake.spin(forward,90,percent);
    }
    if (Controller1.ButtonR2.pressing()){
      intake.spin(reverse,90,percent);
    }
    if(!Controller1.ButtonR2.pressing()&& !Controller1.ButtonR1.pressing()){
    intake.stop();
      }
  
    //cata

    if (toggle){
      cata.spin(reverse,100,percent); 
    } 
    else {
      cata.stop();
    }
    if (Controller1.ButtonL2.pressing()) {
      if(!latch){ 
        toggle = !toggle;
        latch = true;
      }
      if(toggle == false) {
        catapos(330);
      }
    } 
    else {
      latch = false; 
    }

    //hang

    if (toggle2){
      hang.set(true);
    } 
    else {
      hang.set(false);
    }

    if (Controller1.ButtonY.pressing()) {
      if(!latch2){ 
        toggle2 = !toggle2;
        latch2 = true;
      }
      if(toggle2 == true) {
        catapos(355);
      }
    } 
    else {
      latch2 = false; 
    }

    // wings

    if (toggle3){
      wings.set(true);
    } 
    else {
      wings.set(false);
    }

    if (Controller1.ButtonL1.pressing()) {
      if(!latch3){ 
        toggle3 = !toggle3;
        latch3 = true;
      }
    } 
    else {
      latch3 = false; 
    }
  }
  
  
}

int main() {
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);
  pre_auton();
while (true) {
  
  wait(20, msec);
  }
}
  



