#include "vex.h"

// near

void auton1() { 
  chassis.drive_time(0.4, 50);
  wings.set(true);
  wait(0.3, sec);
  chassis.drive_time(0.6, -50);
  wings.set(false);
  chassis.turn_to_angle(130);
  intake.spin(reverse, 100, percent);
  chassis.drive_distance(35);
  intake.stop();
}

//far

void auton2() {
  wings.set(true);
  chassis.drive_time(0.65, -60);
  wings.set(false);
  wait(0.4, sec);
  chassis.turn_to_angle(315);
  chassis.drive_time(0.7, - 70);
  chassis.drive_distance(9);
  chassis.turn_to_angle(104);
  intake.spin(forward, 100, percent);
  chassis.drive_distance(52);
  wait(0.4, sec);
  chassis.turn_to_angle(140);
  intake.stop();
  intake.spin(reverse, 100, percent);
  chassis.drive_distance(15);
  intake.stop();
  chassis.turn_to_angle(250);
  intake.spin(forward, 100, percent);
  chassis.drive_distance(22);
  wait(0.4, sec);
  chassis.turn_to_angle(320);
   wings.set(true);
  chassis.drive_time(0.9, -80);
  intake.stop();
  chassis.drive_time(0.3, 60);
  wings.set(false);
  chassis.turn_to_angle(180);
  chassis.drive_time(0.6, 80);
  chassis.drive_time(0.5, -80);
}

//near elims

void auton3() {
  chassis.drive_distance(43);
  chassis.turn_to_angle(270);
  intake.spin(reverse, 100, percent);
  wait(0.4, sec);
  intake.stop();
  wings.set(true);
  chassis.drive_distance(-25);
  wings.set(false);
  chassis.drive_distance(21);
  chassis.turn_to_angle(270);
  chassis.drive_distance(47);
  chassis.turn_to_angle(270);
  chassis.drive_distance(22);
  chassis.drive_distance(-30);
}

//skills

void auton4() {
  chassis.drive_time(0.6, -60);//-24
  chassis.turn_to_angle(45);
  chassis.drive_time(0.35, -40);
  chassis.drive_distance(7);
  //chassis.drive_time(0.35, 40);
  chassis.turn_to_angle(68);
  chassis.drive_time(0.2, 30);
  /*
  cata.spin(reverse, 100, percent);
  wait(28, sec);
  catapos(330);
  chassis.turn_to_angle(58);
  chassis.drive_time(0.8, -70);//-40
  chassis.turn_to_angle(319);
  chassis.drive_distance(-74);
  chassis.turn_to_angle(315);
  //chassis.drive_distance(-26, -60);'
  chassis.drive_time(0.6, -60);
  chassis.turn_to_angle(315);
  chassis.drive_time(0.5, -60);
  chassis.drive_distance(10);
  chassis.turn_to_angle(292);
  chassis.drive_time(0.9, -80);
  chassis.turn_to_angle(135);
  wings.set(true);
  chassis.drive_time(0.8, -100);
  chassis.drive_distance(28);
  wings.set(false);
  chassis.turn_to_angle(85);
  chassis.drive_time(0.5, 80);
  wings.set(true);
  chassis.turn_to_angle(310);
  chassis.drive_time(0.8, -100);
  chassis.drive_time(0.5, 80);
  wings.set(false);
  */
  /*
  chassis.drive_time(0.3, 80);
  wings.set(true);
  chassis.drive_time(1, -80);
  chassis.drive_time(0.3, 80);
  wings.set(false);
  */
}
