/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       eric                                                      */
/*    Created:      Sat Dec 23 2023                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// rf                   motor         1               
// rm                   motor         2               
// rb                   motor         3               
// lf                   motor         4               
// lm                   motor         5               
// lb                   motor         6               
// cata                 motor         11              
// intake               motor         12              
// Inertial             inertial      7               
// Rotation             rotation      8               
// wings                digital_out   A               
// hang                 digital_out   B               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

competition Competition;

float pi = 3.1415;
float diameter = 2.75;
float ratio = 0.75;
bool toggle = false; 
bool latch = false;
bool toggle2 = false; 
bool latch2 = false;
bool toggle3 = false; 
bool latch3 = false;

void dt(double x,double y) {
  double rightspeed = (Controller1.Axis3.position() * y) + (Controller1.Axis4.position() * -x);
  double leftspeed = (Controller1.Axis3.position() * y) - (Controller1.Axis4.position() * -x);
  lf.setVelocity(leftspeed,percent);
  lm.setVelocity(leftspeed,percent);
  lb.setVelocity(leftspeed,percent);
  rf.setVelocity(rightspeed,percent);
  rm.setVelocity(rightspeed,percent);
  rb.setVelocity(rightspeed,percent);
  lf.spin(forward);
  lm.spin(forward);
  lb.spin(forward);
  rf.spin(forward);
  rm.spin(forward);
  rb.spin(forward);
}

void turn_to_angle(float targetAngle) {
   
    Inertial.setHeading(0, degrees);
    float kp = 0.6; 
    float ki = 0;
    float kd = 1;
    float starti = 15;
    float settle_error = 1; 
    float settle_time = 40.0; 
    float timeout = 1000.0; 


    float accumulated_error = 0;
    float previous_error = 0;
    float output = 0;
    float time_spent_settled = 0;
    float time_spent_running = 0;


    float currentAngle = 0;

    while (true) {

        currentAngle = Inertial.heading(degrees);


        float error = targetAngle - currentAngle;
        

        if (error > 180) {
          error -= 360;
        }
        if (error < -180) {
          error += 360;
        }


        if (fabs(error) < starti) {
            accumulated_error += error;
        }
        if ((error > 0 && previous_error < 0) || (error < 0 && previous_error > 0)) {
            accumulated_error = 0;
        }

        output = kp * error + ki * accumulated_error + kd * (error - previous_error);
        previous_error = error;

        if (fabs(error) < settle_error) {
            time_spent_settled += 20;
        } else {
            time_spent_settled = 0;
        }

        time_spent_running += 20;


        lf.spin(forward, output, percent);
        lm.spin(forward, output, percent);
        lb.spin(forward, output, percent);
        rf.spin(reverse, output, percent);
        rm.spin(reverse, output, percent);
        rb.spin(reverse, output, percent);


        if (time_spent_running > timeout || time_spent_settled > settle_time) {
            break; 
        }

        wait(20, msec); 
        
    }

    lf.stop();
    lm.stop();
    lb.stop();
    rf.stop();
    rm.stop();
    rb.stop();
}

void Forward(double duration, int speed) {
    
    rf.spin(forward, speed, percent);
    rm.spin(forward, speed, percent);
    rb.spin(forward, speed, percent);
    lf.spin(forward, speed, percent);
    lm.spin(forward, speed, percent);
    lb.spin(forward, speed, percent);

    double stopTime = Brain.timer(vex::timeUnits::sec) + duration;

    while (Brain.timer(vex::timeUnits::sec) < stopTime) {
    }

    rf.stop();
    rm.stop();
    rb.stop();
    lf.stop();
    lm.stop();
    lb.stop();
}


void Backward(double duration, int speed) {
    
    rf.spin(reverse, speed, percent);
    rm.spin(reverse, speed, percent);
    rb.spin(reverse, speed, percent);
    lf.spin(reverse, speed, percent);
    lm.spin(reverse, speed, percent);
    lb.spin(reverse, speed, percent);

    double stopTime = Brain.timer(vex::timeUnits::sec) + duration;

    while (Brain.timer(vex::timeUnits::sec) < stopTime) {
    }

    
    rf.stop();
    rm.stop();
    rb.stop();
    lf.stop();
    lm.stop();
    lb.stop();
}

void catapos(float targetAngle) {

  float currentAngle = 0;
  float error = targetAngle - currentAngle;
  cata.stop();
  cata.spin(reverse, 45, percent); 
  while (fabs(error) >= 10) {
    wait(10, msec);
    currentAngle = Rotation.position(deg);
    error = targetAngle - currentAngle;
  }
  cata.stop();
}

void auton1() {
  Backward(0.7, 60);
  turn_to_angle(45);
  Backward(0.5, 60);
  Forward(0.5, 60);
  turn_to_angle(60);
  cata.spin(reverse, 100, percent);
  wait(3, sec);
  catapos(320);
  turn_to_angle(50);
  Backward(0.9, 60);
  turn_to_angle(330);
  Backward(1.5, 80);
  turn_to_angle(315);
  Backward(0.7, 60);
  turn_to_angle(320);
  Backward(0.5, 60);
  Forward(0.3, 60);
  turn_to_angle(290);
  Backward(1, 80);
  turn_to_angle(125);
  wings.set(true);
  Backward(1, 80);
  Forward(0.5, 80);
  wings.set(false);
  turn_to_angle(90);
  Forward(0.5, 80);
  turn_to_angle(310);
  wings.set(true);
  Backward(1, 80);






  

}


int auton = 1;
int noa = 4;
void autonselector() {
 if (auton>noa){
   auton=1;
 }
if (auton<1){
   auton=noa;
}
if(Controller1.Axis1.position(percent) > 5){
   auton++;
   wait(0.5,seconds);
}
if(Controller1.Axis1.position(percent) < -5){
   auton--;
   wait(0.5,seconds);
}
if(auton == 1){
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1,1);
  Controller1.Screen.print("Far");
}
if(auton == 2){
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1,1);
  Controller1.Screen.print("Near");
  }
if(auton == 3){
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1,1);
  Controller1.Screen.print("NearElims");
  }  
if(auton == 4){
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1,1);
  Controller1.Screen.print("Skills");
  }  
}

void pre_auton(void) {

}

void autonomous(void) {

  lf.setStopping(hold);
  lm.setStopping(hold);
  lb.setStopping(hold);
  rf.setStopping(hold);
  rm.setStopping(hold);
  rb.setStopping(hold);
  
  if (auton == 1){
    auton1();
  }
}


void usercontrol(void) {

  while (true){
    dt(0.5, 1);
    lf.setStopping(coast);
    lm.setStopping(coast);
    lb.setStopping(brake);
    rf.setStopping(coast);
    rm.setStopping(coast);
    rb.setStopping(brake);

    // intake

    if (Controller1.ButtonR1.pressing()){
      intake.spin(forward,90,percent);
    }
    if (Controller1.ButtonR2.pressing()){
      intake.spin(reverse,90,percent);
    }
    if(!Controller1.ButtonR2.pressing()&& !Controller1.ButtonR1.pressing()){
    intake.stop();
      }
  
    //cata

    if (toggle){
      cata.spin(reverse,100,percent); 
    } 
    else {
      cata.stop();
    }
    if (Controller1.ButtonA.pressing()) {
      if(!latch){ 
        toggle = !toggle;
        latch = true;
      }
      if(toggle == false) {
        catapos(320);
      }
    } 
    else {
      latch = false; 
    }

    //hang

    if (toggle2){
      hang.set(true);
    } 
    else {
      hang.set(false);
    }

    if (Controller1.ButtonY.pressing()) {
      if(!latch2){ 
        toggle2 = !toggle2;
        latch2 = true;
      }
      if(toggle2 == true) {
        catapos(350);
      }
    } 
    else {
      latch2 = false; 
    }

    // wings

    if (toggle3){
      wings.set(true);
    } 
    else {
      wings.set(false);
    }

    if (Controller1.ButtonL1.pressing()) {
      if(!latch3){ 
        toggle3 = !toggle3;
        latch3 = true;
      }
    } 
    else {
      latch3 = false; 
    }
  }
}

int main() {
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);
  pre_auton();
while (true) {
  
  wait(20,msec);
  }
}
  



